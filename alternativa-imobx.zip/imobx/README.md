# Alternativa ImobX — CRM Imobiliário

## Como colocar no ar (Vercel)

### 1. Instale as dependências
```bash
npm install
```

### 2. Teste localmente
```bash
npm start
```
Acesse: http://localhost:3000

### 3. Suba para o GitHub
```bash
git init
git add .
git commit -m "Alternativa ImobX CRM"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/alternativa-imobx.git
git push -u origin main
```

### 4. Deploy no Vercel
1. Acesse vercel.com e faça login com GitHub
2. Clique em "Add New Project"
3. Selecione o repositório alternativa-imobx
4. Clique em Deploy

Pronto! URL gerada automaticamente.

## Usuários de acesso (demo)
| Nome | E-mail | Senha | Cargo |
|------|--------|-------|-------|
| Ana Lima | ana@imobx.com | 123 | Gerente (Admin) |
| Pedro Rocha | pedro@imobx.com | 123 | Corretor Sênior |
| Lucas Matos | lucas@imobx.com | 123 | Corretor |
| Camila Torres | camila@imobx.com | 123 | Corretora |
| Rafael Dias | rafael@imobx.com | 123 | Corretor Jr. |
