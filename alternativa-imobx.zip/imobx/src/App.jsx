import { useState, useEffect } from "react";

// ══════════════════════════════════════════════════════════
// DADOS
// ══════════════════════════════════════════════════════════
const USERS = [
  { id:1, nome:"Ana Lima",      email:"ana@imobx.com",    senha:"123", cargo:"Gerente",         role:"admin",    av:"AL", cor:"#C9A96E" },
  { id:2, nome:"Pedro Rocha",   email:"pedro@imobx.com",  senha:"123", cargo:"Corretor Sênior", role:"corretor", av:"PR", cor:"#3b82f6" },
  { id:3, nome:"Lucas Matos",   email:"lucas@imobx.com",  senha:"123", cargo:"Corretor",        role:"corretor", av:"LM", cor:"#10b981" },
  { id:4, nome:"Camila Torres", email:"camila@imobx.com", senha:"123", cargo:"Corretora",       role:"corretor", av:"CT", cor:"#ec4899" },
  { id:5, nome:"Rafael Dias",   email:"rafael@imobx.com", senha:"123", cargo:"Corretor Jr.",    role:"corretor", av:"RD", cor:"#8b5cf6" },
];

const STATUS_LEAD = [
  { k:"novo",       l:"Novo Lead",       c:"#3b82f6" },
  { k:"contato",    l:"Em Contato",      c:"#8b5cf6" },
  { k:"visita",     l:"Visita Agendada", c:"#f59e0b" },
  { k:"proposta",   l:"Proposta",        c:"#ec4899" },
  { k:"negociacao", l:"Negociação",      c:"#f97316" },
  { k:"ganho",      l:"Ganho ✓",         c:"#10b981" },
  { k:"perdido",    l:"Perdido ✗",       c:"#6b7280" },
];

const ORIGENS = ["Site","WhatsApp","Instagram","Google","Indicação","Portais","Facebook","Outro"];

const LEADS0 = [
  { id:1,  nome:"Carlos Ferreira",  tel:"(11) 98765-4321", email:"carlos@email.com",   origem:"Site",      interesse:"Compra",  orc:850000,  bairro:"Jardins",       tipo:"Apartamento",    status:"novo",       corretor:"Ana Lima",     dt:"2025-05-10", notas:"Quer 3 quartos, aceita financiamento.", score:87 },
  { id:2,  nome:"Mariana Souza",    tel:"(11) 91234-5678", email:"mari@gmail.com",      origem:"WhatsApp",  interesse:"Aluguel", orc:4500,    bairro:"Vila Madalena",  tipo:"Casa",           status:"contato",    corretor:"Pedro Rocha",  dt:"2025-05-11", notas:"Busca imóvel pet-friendly.",           score:72 },
  { id:3,  nome:"Roberto Alves",    tel:"(11) 97777-3333", email:"roberto@empresa.com", origem:"Indicação", interesse:"Compra",  orc:2500000, bairro:"Moema",          tipo:"Cobertura",      status:"visita",     corretor:"Ana Lima",     dt:"2025-05-08", notas:"Cliente VIP. Quer vista panorâmica.",  score:95 },
  { id:4,  nome:"Fernanda Costa",   tel:"(11) 96666-2222", email:"fecosta@hotmail.com", origem:"Instagram", interesse:"Compra",  orc:600000,  bairro:"Campo Belo",     tipo:"Apartamento",    status:"proposta",   corretor:"Lucas Matos",  dt:"2025-05-07", notas:"Já visitou 2 imóveis.",                score:91 },
  { id:5,  nome:"João Mendes",      tel:"(11) 95555-1111", email:"joao@gmail.com",      origem:"Google",    interesse:"Aluguel", orc:8000,    bairro:"Faria Lima",     tipo:"Sala Comercial", status:"negociacao", corretor:"Lucas Matos",  dt:"2025-05-06", notas:"Empresa em expansão. 80m²+.",          score:78 },
  { id:6,  nome:"Patrícia Lima",    tel:"(11) 94444-0000", email:"patricia@email.com",  origem:"Site",      interesse:"Compra",  orc:1200000, bairro:"Alphaville",     tipo:"Casa",           status:"ganho",      corretor:"Ana Lima",     dt:"2025-05-03", notas:"Fechamento realizado!",                score:99 },
  { id:7,  nome:"Thiago Nunes",     tel:"(11) 93333-8888", email:"thiago@email.com",    origem:"Portais",   interesse:"Compra",  orc:450000,  bairro:"Santana",        tipo:"Apartamento",    status:"perdido",    corretor:"Pedro Rocha",  dt:"2025-05-01", notas:"Comprou com outra imobiliária.",       score:34 },
  { id:8,  nome:"Beatriz Neves",    tel:"(11) 92222-7777", email:"bea@email.com",       origem:"Facebook",  interesse:"Aluguel", orc:3200,    bairro:"Pinheiros",      tipo:"Apartamento",    status:"novo",       corretor:"Camila Torres",dt:"2025-05-13", notas:"",                                    score:55 },
  { id:9,  nome:"Gustavo Melo",     tel:"(11) 91111-6666", email:"gustavo@email.com",   origem:"Google",    interesse:"Compra",  orc:980000,  bairro:"Itaim Bibi",     tipo:"Apartamento",    status:"contato",    corretor:"Rafael Dias",  dt:"2025-05-14", notas:"Primeira compra.",                     score:63 },
  { id:10, nome:"Sandra Oliveira",  tel:"(11) 90000-5555", email:"sandra@email.com",    origem:"WhatsApp",  interesse:"Compra",  orc:720000,  bairro:"Brooklin",       tipo:"Apartamento",    status:"visita",     corretor:"Camila Torres",dt:"2025-05-15", notas:"Quer imóvel próximo ao metrô.",        score:80 },
];

const IMOVEIS0 = [
  { id:1, cod:"ALT-001", titulo:"Apartamento Luxo Jardins",     tipo:"Apartamento",    fin:"Venda",  preco:1850000, area:142, qts:3, bhs:2, vgs:2, bairro:"Jardins",       end:"R. Oscar Freire, 1200",  status:"disponivel", corretor:"Ana Lima",     vis:8,  foto:"https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&q=70" },
  { id:2, cod:"ALT-002", titulo:"Casa Alto Padrão Alphaville",  tipo:"Casa",           fin:"Venda",  preco:3200000, area:380, qts:5, bhs:4, vgs:4, bairro:"Alphaville",    end:"Al. das Flores, 45",     status:"reservado",  corretor:"Pedro Rocha",  vis:5,  foto:"https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&q=70" },
  { id:3, cod:"ALT-003", titulo:"Studio Vila Madalena",         tipo:"Apartamento",    fin:"Aluguel",preco:3800,    area:45,  qts:1, bhs:1, vgs:1, bairro:"Vila Madalena", end:"R. Aspicuelta, 88",      status:"disponivel", corretor:"Lucas Matos",  vis:12, foto:"https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&q=70" },
  { id:4, cod:"ALT-004", titulo:"Cobertura Duplex Moema",       tipo:"Cobertura",      fin:"Venda",  preco:4700000, area:290, qts:4, bhs:5, vgs:3, bairro:"Moema",         end:"Av. Ibirapuera, 3103",   status:"disponivel", corretor:"Ana Lima",     vis:3,  foto:"https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=70" },
  { id:5, cod:"ALT-005", titulo:"Sala Comercial Faria Lima",    tipo:"Sala Comercial", fin:"Aluguel",preco:8500,    area:85,  qts:0, bhs:2, vgs:2, bairro:"Pinheiros",     end:"Av. Faria Lima, 2000",   status:"negociacao", corretor:"Lucas Matos",  vis:7,  foto:"https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=70" },
  { id:6, cod:"ALT-006", titulo:"Casa Condomínio Granja Viana", tipo:"Casa",           fin:"Aluguel",preco:12000,   area:260, qts:4, bhs:3, vgs:3, bairro:"Cotia",         end:"Est. da Granja, 900",    status:"disponivel", corretor:"Camila Torres",vis:4,  foto:"https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600&q=70" },
  { id:7, cod:"ALT-007", titulo:"Apto 2 Dorm. Campo Belo",      tipo:"Apartamento",    fin:"Venda",  preco:780000,  area:78,  qts:2, bhs:2, vgs:1, bairro:"Campo Belo",    end:"R. Fernão Dias, 340",    status:"disponivel", corretor:"Rafael Dias",  vis:6,  foto:"https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&q=70" },
];

const VISITAS0 = [
  { id:1, lead:"Roberto Alves",   imovel:"Cobertura Duplex Moema",   corretor:"Ana Lima",     data:"2025-05-16", hora:"10:00", status:"agendada",  obs:"Cliente VIP, levar material." },
  { id:2, lead:"Fernanda Costa",  imovel:"Apartamento Luxo Jardins", corretor:"Lucas Matos",  data:"2025-05-16", hora:"14:30", status:"agendada",  obs:"Segunda visita." },
  { id:3, lead:"Carlos Ferreira", imovel:"Studio Vila Madalena",     corretor:"Ana Lima",     data:"2025-05-17", hora:"09:00", status:"agendada",  obs:"" },
  { id:4, lead:"Sandra Oliveira", imovel:"Apto 2 Dorm. Campo Belo",  corretor:"Camila Torres",data:"2025-05-17", hora:"11:00", status:"agendada",  obs:"Quer imóvel próximo ao metrô." },
  { id:5, lead:"João Mendes",     imovel:"Sala Comercial Faria Lima", corretor:"Lucas Matos",  data:"2025-05-14", hora:"11:00", status:"realizada", obs:"Gostou, pediu proposta." },
  { id:6, lead:"Thiago Nunes",    imovel:"Apto 2 Dorm. Campo Belo",  corretor:"Pedro Rocha",  data:"2025-05-12", hora:"15:00", status:"cancelada", obs:"Lead cancelou." },
];

// ══════════════════════════════════════════════════════════
// UTILS
// ══════════════════════════════════════════════════════════
const uid  = () => Date.now().toString(36) + Math.random().toString(36).slice(2);
const fmtM = (v) => +v >= 1e6 ? `R$ ${(+v/1e6).toFixed(2).replace(".",",")}Mi` : `R$ ${(+v).toLocaleString("pt-BR")}`;
const fmtD = (d) => d ? new Date(d+"T12:00").toLocaleDateString("pt-BR") : "";
const slObj = Object.fromEntries(STATUS_LEAD.map(s=>[s.k,s]));
const uObj  = Object.fromEntries(USERS.map(u=>[u.nome,u]));

// ══════════════════════════════════════════════════════════
// ICONS
// ══════════════════════════════════════════════════════════
const SVG = {
  home:"M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6",
  users:"M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z",
  build:"M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4",
  cal:"M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z",
  funnel:"M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z",
  plus:"M12 4v16m8-8H4",
  search:"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z",
  edit:"M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z",
  trash:"M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16",
  x:"M6 18L18 6M6 6l12 12",
  check:"M5 13l4 4L19 7",
  star:"M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z",
  ai:"M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z",
  send:"M12 19l9 2-9-18-9 18 9-2zm0 0v-8",
  mail:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z",
  phone:"M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z",
  pin:"M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z M15 11a3 3 0 11-6 0 3 3 0 016 0z",
  key:"M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z",
  logout:"M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1",
  shield:"M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
  lock:"M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z",
  eye:"M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z",
  eyeoff:"M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21",
  menu:"M4 6h16M4 12h16M4 18h16",
  bell:"M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9",
  user:"M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z",
  team:"M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z",
  bed:"M2 4v16M22 4v16M2 8h20M2 16h20M6 8v8M18 8v8",
  car:"M5 17H3a2 2 0 01-2-2V9a2 2 0 012-2h14a2 2 0 012 2v1m-4 9H9m8 0h2a2 2 0 002-2v-4a2 2 0 00-2-2h-2m-8 0V9",
  tag:"M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z",
  arrow:"M14 5l7 7m0 0l-7 7m7-7H3",
  grid:"M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z",
  list:"M4 6h16M4 10h16M4 14h16M4 18h16",
  whats:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a9.734 9.734 0 00-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z",
};
const Ic = ({ n, s=18, c="currentColor", sw=1.8 }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    <path d={SVG[n]}/>
  </svg>
);

// ── Base Components ──────────────────────────────────────
const Score = ({ v }) => {
  const c = v>=80?"#10b981":v>=55?"#f59e0b":"#ef4444";
  return (
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      <div style={{flex:1,height:4,background:"#252525",borderRadius:99,overflow:"hidden"}}>
        <div style={{width:`${v}%`,height:"100%",background:c,borderRadius:99}}/>
      </div>
      <span style={{fontSize:11,fontWeight:700,color:c,minWidth:24,textAlign:"right"}}>{v}</span>
    </div>
  );
};

const Badge = ({ s }) => {
  const o = slObj[s]||{l:s,c:"#6b7280"};
  return <span style={{background:o.c+"20",color:o.c,border:`1px solid ${o.c}35`,padding:"2px 9px",borderRadius:99,fontSize:11,fontWeight:700,whiteSpace:"nowrap"}}>{o.l}</span>;
};

const Avatar = ({ nome, cor, size=32, fontSize=12 }) => (
  <div style={{width:size,height:size,borderRadius:"50%",background:cor||"#C9A96E",display:"flex",alignItems:"center",justifyContent:"center",fontSize,fontWeight:700,color:"#000",flexShrink:0}}>
    {nome?.slice(0,2).toUpperCase()}
  </div>
);

const Modal = ({ title, onClose, children, wide }) => {
  useEffect(()=>{document.body.style.overflow="hidden";return()=>{document.body.style.overflow="";};},[]);
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className={`modal-box${wide?" wide":""}`} onClick={e=>e.stopPropagation()}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="ib" onClick={onClose}><Ic n="x" s={18}/></button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
};

const Confirm = ({ msg, onOk, onCancel }) => (
  <Modal title="Confirmar ação" onClose={onCancel}>
    <p style={{color:"#bbb",marginBottom:24,lineHeight:1.6}}>{msg}</p>
    <div className="row-end gap8">
      <button className="btn-ghost" onClick={onCancel}>Cancelar</button>
      <button className="btn-danger" onClick={onOk}><Ic n="trash" s={14}/> Excluir</button>
    </div>
  </Modal>
);

// ══════════════════════════════════════════════════════════
// LOGIN
// ══════════════════════════════════════════════════════════
const Login = ({ onLogin }) => {
  const [email,setEmail] = useState("");
  const [senha,setSenha] = useState("");
  const [show,setShow]   = useState(false);
  const [erro,setErro]   = useState("");
  const [load,setLoad]   = useState(false);
  const [quick,setQuick] = useState(null);

  const go = (em,sn) => {
    setLoad(true); setErro("");
    setTimeout(()=>{
      const u = USERS.find(u=>u.email===em&&u.senha===sn);
      u ? onLogin(u) : (setErro("E-mail ou senha incorretos."),setLoad(false));
    },700);
  };

  return (
    <div className="login-root">
      <div className="login-panel">
        <div className="login-brand">
          <div className="brand-mark">A</div>
          <div><p className="brand-eye">ALTERNATIVA</p><p className="brand-name">IMOB<span>X</span></p></div>
        </div>
        <h1 className="login-h1">CRM Imobiliário</h1>
        <p className="login-sub">Entre com suas credenciais para acessar o sistema</p>
        <div className="lf-field">
          <label>E-mail</label>
          <div className="lf-wrap">
            <Ic n="mail" s={16} c="#555"/>
            <input type="email" placeholder="seu@imobx.com" value={email} onChange={e=>{setEmail(e.target.value);setQuick(null);}} onKeyDown={e=>e.key==="Enter"&&go(email,senha)}/>
          </div>
        </div>
        <div className="lf-field">
          <label>Senha</label>
          <div className="lf-wrap">
            <Ic n="lock" s={16} c="#555"/>
            <input type={show?"text":"password"} placeholder="••••••" value={senha} onChange={e=>{setSenha(e.target.value);setQuick(null);}} onKeyDown={e=>e.key==="Enter"&&go(email,senha)}/>
            <button className="lf-eye" onClick={()=>setShow(!show)}><Ic n={show?"eyeoff":"eye"} s={15} c="#555"/></button>
          </div>
        </div>
        {erro&&<div className="lf-erro"><Ic n="x" s={13} c="#ef4444"/> {erro}</div>}
        <button className="btn-login" disabled={load} onClick={()=>go(email,senha)}>
          {load?<span className="spinner"/>:<><Ic n="key" s={16} c="#000"/> Entrar no sistema</>}
        </button>
        <div className="demo-sep"><span>Acesso rápido — demo</span></div>
        <div className="demo-grid">
          {USERS.map(u=>(
            <button key={u.id} className={`demo-btn${quick?.id===u.id?" sel":""}`} onClick={()=>{setQuick(u);setEmail(u.email);setSenha(u.senha);}}>
              <Avatar nome={u.av} cor={u.cor} size={28} fontSize={10}/>
              <div style={{textAlign:"left"}}><div className="demo-nome">{u.nome.split(" ")[0]}</div><div className="demo-cargo">{u.cargo}</div></div>
              {u.role==="admin"&&<span className="demo-admin">Admin</span>}
            </button>
          ))}
        </div>
        {quick&&<button className="btn-quick" onClick={()=>go(quick.email,quick.senha)}><Ic n="arrow" s={15} c="#000"/> Entrar como {quick.nome.split(" ")[0]}</button>}
      </div>
      <div className="login-visual">
        <div className="lv-bg"/>
        <div className="lv-overlay"/>
        <div className="lv-content">
          <h2>Gerencie sua imobiliária com inteligência</h2>
          <p>CRM completo com pipeline de vendas, agenda de visitas, cadastro de imóveis e análise de leads com IA.</p>
          <div className="lv-features">
            {["Pipeline de Vendas Kanban","Análise de Leads com IA","Agenda de Visitas","Gestão de Imóveis","Acesso por Corretor","Dashboard em Tempo Real"].map((f,i)=>(
              <div key={i} className="lv-feat"><Ic n="check" s={14} c="#C9A96E" sw={2.5}/>{f}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════
// AI PANEL
// ══════════════════════════════════════════════════════════
const AIPanel = ({ lead, onClose }) => {
  const [res,setRes]   = useState("");
  const [load,setLoad] = useState(false);
  const [pr,setPr]     = useState("");

  const run = async (tipo) => {
    setLoad(true); setRes("");
    const ps = {
      analise:`Você é especialista em vendas imobiliárias. Analise este lead:\nNome: ${lead.nome}\nInteresse: ${lead.interesse}\nOrçamento: ${fmtM(lead.orc)}\nBairro: ${lead.bairro}\nTipo: ${lead.tipo}\nOrigem: ${lead.origem}\nScore: ${lead.score}/100\nNotas: ${lead.notas||"(sem notas)"}\n\nDê: 1) Potencial de fechamento 2) Próximos 3 passos concretos 3) Argumentos de venda personalizados 4) Alertas de risco.`,
      email:`Escreva um e-mail de follow-up profissional para:\nNome: ${lead.nome}\nInteresse: ${lead.interesse} de ${lead.tipo} em ${lead.bairro}\nOrçamento: ${fmtM(lead.orc)}\n\nE-mail personalizado. Assinar pela Alternativa ImobX.`,
      whats:`Mensagem de WhatsApp para follow-up:\nNome: ${lead.nome}\nInteresse: ${lead.interesse} de ${lead.tipo} em ${lead.bairro}\nOrçamento: ${fmtM(lead.orc)}\n\nMensagem curta, amigável, máx 3 parágrafos. Call-to-action claro.`,
      custom:pr,
    };
    try {
      const r = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:ps[tipo]}]})
      });
      const d = await r.json();
      setRes(d.content?.[0]?.text||"Erro na resposta.");
    } catch { setRes("Erro ao conectar com a IA."); }
    setLoad(false);
  };

  return (
    <Modal title={`✦ IA — ${lead.nome}`} onClose={onClose} wide>
      <div className="ai-wrap">
        <div className="ai-lead-info">
          <Avatar nome={lead.nome.slice(0,2)} cor={uObj[lead.corretor]?.cor} size={40}/>
          <div style={{flex:1}}><div className="ai-nome">{lead.nome}</div><div className="ai-meta">{lead.interesse} · {lead.tipo} · {lead.bairro} · {fmtM(lead.orc)}</div></div>
          <div style={{minWidth:90}}><Score v={lead.score}/></div>
        </div>
        <div className="ai-actions">
          <button className="ai-act-btn" onClick={()=>run("analise")}><Ic n="ai" s={15}/> Analisar</button>
          <button className="ai-act-btn" onClick={()=>run("email")}><Ic n="mail" s={15}/> E-mail</button>
          <button className="ai-act-btn" onClick={()=>run("whats")}><Ic n="whats" s={15}/> WhatsApp</button>
        </div>
        <div className="ai-input-row">
          <input placeholder="Pergunta personalizada..." value={pr} onChange={e=>setPr(e.target.value)} onKeyDown={e=>e.key==="Enter"&&pr&&run("custom")}/>
          <button className="ai-send" onClick={()=>pr&&run("custom")}><Ic n="send" s={16} c="#000"/></button>
        </div>
        <div className="ai-output">
          {load&&<div className="ai-loading"><div className="dots"><s/><s/><s/></div><span>Analisando...</span></div>}
          {!load&&res&&<div className="ai-text">{res.split("\n").map((l,i)=>l?<p key={i}>{l}</p>:<br key={i}/>)}</div>}
          {!load&&!res&&<div className="ai-empty"><Ic n="ai" s={32} c="#C9A96E"/><p>Selecione uma ação acima</p></div>}
        </div>
      </div>
    </Modal>
  );
};

// ══════════════════════════════════════════════════════════
// FORM LEAD
// ══════════════════════════════════════════════════════════
const FormLead = ({ lead, onSave, onClose, user }) => {
  const isAdmin = user.role==="admin";
  const [f,setF] = useState(lead||{nome:"",tel:"",email:"",origem:"Site",interesse:"Compra",orc:"",bairro:"",tipo:"Apartamento",status:"novo",corretor:user.nome,notas:"",score:60});
  const s = (k,v) => setF(p=>({...p,[k]:v}));
  const ok = () => { if(!f.nome.trim()) return; onSave({...f,id:lead?.id||uid(),dt:lead?.dt||new Date().toISOString().split("T")[0]}); };
  return (
    <Modal title={lead?"Editar Lead":"Novo Lead"} onClose={onClose}>
      <div className="form-g">
        <div className="fg"><label>Nome *</label><input value={f.nome} onChange={e=>s("nome",e.target.value)} placeholder="Nome completo"/></div>
        <div className="fg"><label>Telefone</label><input value={f.tel} onChange={e=>s("tel",e.target.value)} placeholder="(11) 9 9999-9999"/></div>
        <div className="fg"><label>E-mail</label><input type="email" value={f.email} onChange={e=>s("email",e.target.value)}/></div>
        <div className="fg"><label>Origem</label><select value={f.origem} onChange={e=>s("origem",e.target.value)}>{ORIGENS.map(o=><option key={o}>{o}</option>)}</select></div>
        <div className="fg"><label>Interesse</label><select value={f.interesse} onChange={e=>s("interesse",e.target.value)}><option>Compra</option><option>Aluguel</option><option>Venda</option></select></div>
        <div className="fg"><label>Orçamento (R$)</label><input type="number" value={f.orc} onChange={e=>s("orc",e.target.value)}/></div>
        <div className="fg"><label>Bairro desejado</label><input value={f.bairro} onChange={e=>s("bairro",e.target.value)}/></div>
        <div className="fg"><label>Tipo</label><select value={f.tipo} onChange={e=>s("tipo",e.target.value)}><option>Apartamento</option><option>Casa</option><option>Cobertura</option><option>Terreno</option><option>Sala Comercial</option></select></div>
        <div className="fg"><label>Status</label><select value={f.status} onChange={e=>s("status",e.target.value)}>{STATUS_LEAD.map(sl=><option key={sl.k} value={sl.k}>{sl.l}</option>)}</select></div>
        <div className="fg"><label>Corretor</label>
          <select value={f.corretor} onChange={e=>s("corretor",e.target.value)} disabled={!isAdmin}>
            {USERS.map(u=><option key={u.id}>{u.nome}</option>)}
          </select>
        </div>
        <div className="fg full"><label>Score: {f.score}</label>
          <input type="range" min={0} max={100} value={f.score} onChange={e=>s("score",+e.target.value)} style={{accentColor:"#C9A96E"}}/>
          <Score v={f.score}/>
        </div>
        <div className="fg full"><label>Notas</label><textarea rows={3} value={f.notas} onChange={e=>s("notas",e.target.value)}/></div>
      </div>
      <div className="row-end gap8" style={{marginTop:16,paddingTop:14,borderTop:"1px solid #222"}}>
        <button className="btn-ghost" onClick={onClose}>Cancelar</button>
        <button className="btn-gold" onClick={ok}><Ic n="check" s={15} c="#000"/> Salvar Lead</button>
      </div>
    </Modal>
  );
};

// ══════════════════════════════════════════════════════════
// FORM IMÓVEL
// ══════════════════════════════════════════════════════════
const FormImovel = ({ im, onSave, onClose, user }) => {
  const isAdmin = user.role==="admin";
  const [f,setF] = useState(im||{titulo:"",tipo:"Apartamento",fin:"Venda",preco:"",area:"",qts:"",bhs:"",vgs:"",bairro:"",end:"",status:"disponivel",corretor:user.nome,foto:"",cod:`ALT-${String(Date.now()).slice(-3)}`});
  const s = (k,v) => setF(p=>({...p,[k]:v}));
  const ok = () => { if(!f.titulo.trim()) return; onSave({...f,id:im?.id||uid(),vis:im?.vis||0}); };
  return (
    <Modal title={im?"Editar Imóvel":"Novo Imóvel"} onClose={onClose}>
      <div className="form-g">
        <div className="fg full"><label>Título *</label><input value={f.titulo} onChange={e=>s("titulo",e.target.value)}/></div>
        <div className="fg"><label>Tipo</label><select value={f.tipo} onChange={e=>s("tipo",e.target.value)}><option>Apartamento</option><option>Casa</option><option>Cobertura</option><option>Terreno</option><option>Sala Comercial</option></select></div>
        <div className="fg"><label>Finalidade</label><select value={f.fin} onChange={e=>s("fin",e.target.value)}><option>Venda</option><option>Aluguel</option></select></div>
        <div className="fg"><label>Preço (R$)</label><input type="number" value={f.preco} onChange={e=>s("preco",e.target.value)}/></div>
        <div className="fg"><label>Área (m²)</label><input type="number" value={f.area} onChange={e=>s("area",e.target.value)}/></div>
        <div className="fg"><label>Quartos</label><input type="number" min={0} value={f.qts} onChange={e=>s("qts",e.target.value)}/></div>
        <div className="fg"><label>Banheiros</label><input type="number" min={0} value={f.bhs} onChange={e=>s("bhs",e.target.value)}/></div>
        <div className="fg"><label>Vagas</label><input type="number" min={0} value={f.vgs} onChange={e=>s("vgs",e.target.value)}/></div>
        <div className="fg"><label>Bairro</label><input value={f.bairro} onChange={e=>s("bairro",e.target.value)}/></div>
        <div className="fg"><label>Endereço</label><input value={f.end} onChange={e=>s("end",e.target.value)}/></div>
        <div className="fg"><label>Status</label><select value={f.status} onChange={e=>s("status",e.target.value)}><option value="disponivel">Disponível</option><option value="reservado">Reservado</option><option value="negociacao">Em Negociação</option><option value="vendido">Vendido/Alugado</option></select></div>
        <div className="fg"><label>Corretor</label><select value={f.corretor} onChange={e=>s("corretor",e.target.value)} disabled={!isAdmin}>{USERS.map(u=><option key={u.id}>{u.nome}</option>)}</select></div>
        <div className="fg full"><label>URL da Foto</label><input value={f.foto} onChange={e=>s("foto",e.target.value)} placeholder="https://..."/></div>
      </div>
      <div className="row-end gap8" style={{marginTop:16,paddingTop:14,borderTop:"1px solid #222"}}>
        <button className="btn-ghost" onClick={onClose}>Cancelar</button>
        <button className="btn-gold" onClick={ok}><Ic n="check" s={15} c="#000"/> Salvar Imóvel</button>
      </div>
    </Modal>
  );
};

// ══════════════════════════════════════════════════════════
// FORM VISITA
// ══════════════════════════════════════════════════════════
const FormVisita = ({ onSave, onClose, leads, imoveis, user }) => {
  const isAdmin = user.role==="admin";
  const [f,setF] = useState({lead:leads[0]?.nome||"",imovel:imoveis[0]?.titulo||"",corretor:user.nome,data:new Date().toISOString().split("T")[0],hora:"10:00",status:"agendada",obs:""});
  const s = (k,v) => setF(p=>({...p,[k]:v}));
  return (
    <Modal title="Agendar Visita" onClose={onClose}>
      <div className="form-g">
        <div className="fg"><label>Lead / Cliente</label><select value={f.lead} onChange={e=>s("lead",e.target.value)}>{leads.map(l=><option key={l.id}>{l.nome}</option>)}</select></div>
        <div className="fg"><label>Imóvel</label><select value={f.imovel} onChange={e=>s("imovel",e.target.value)}>{imoveis.map(im=><option key={im.id}>{im.titulo}</option>)}</select></div>
        <div className="fg"><label>Corretor</label><select value={f.corretor} onChange={e=>s("corretor",e.target.value)} disabled={!isAdmin}>{USERS.map(u=><option key={u.id}>{u.nome}</option>)}</select></div>
        <div className="fg"><label>Data</label><input type="date" value={f.data} onChange={e=>s("data",e.target.value)}/></div>
        <div className="fg"><label>Hora</label><input type="time" value={f.hora} onChange={e=>s("hora",e.target.value)}/></div>
        <div className="fg"><label>Status</label><select value={f.status} onChange={e=>s("status",e.target.value)}><option value="agendada">Agendada</option><option value="realizada">Realizada</option><option value="cancelada">Cancelada</option></select></div>
        <div className="fg full"><label>Observações</label><textarea rows={3} value={f.obs} onChange={e=>s("obs",e.target.value)}/></div>
      </div>
      <div className="row-end gap8" style={{marginTop:16,paddingTop:14,borderTop:"1px solid #222"}}>
        <button className="btn-ghost" onClick={onClose}>Cancelar</button>
        <button className="btn-gold" onClick={()=>onSave({...f,id:uid()})}><Ic n="check" s={15} c="#000"/> Agendar</button>
      </div>
    </Modal>
  );
};

// ══════════════════════════════════════════════════════════
// PERFIL
// ══════════════════════════════════════════════════════════
const PerfilModal = ({ user, leads, visitas, onClose }) => {
  const mL = leads.filter(l=>l.corretor===user.nome);
  const mG = mL.filter(l=>l.status==="ganho");
  const mV = visitas.filter(v=>v.corretor===user.nome&&v.status==="agendada");
  const conv = mL.length ? Math.round(mG.length/mL.length*100) : 0;
  return (
    <Modal title="Meu Perfil" onClose={onClose}>
      <div className="perfil-wrap">
        <div className="perfil-top">
          <Avatar nome={user.av} cor={user.cor} size={60} fontSize={20}/>
          <div>
            <h2 style={{fontFamily:"'Bricolage Grotesque',sans-serif",fontSize:20,color:"#fff"}}>{user.nome}</h2>
            <p style={{color:"#888",fontSize:13,marginTop:2}}>{user.cargo}</p>
            {user.role==="admin"&&<span className="admin-chip"><Ic n="shield" s={11} c="#C9A96E"/> Administrador</span>}
          </div>
        </div>
        <div className="perfil-info">
          {[{i:"mail",l:"E-mail",v:user.email},{i:"phone",l:"Telefone",v:"(11) 9 9999-9999"},{i:"key",l:"CRECI",v:`SP-${10000+user.id*3456}`}].map((x,i)=>(
            <div key={i} className="pi-row"><Ic n={x.i} s={15} c="#C9A96E"/><div><span>{x.l}</span><p>{x.v}</p></div></div>
          ))}
        </div>
        <div className="perfil-nums">
          {[{v:mL.length,l:"Leads",c:"#3b82f6"},{v:mG.length,l:"Fechados",c:"#10b981"},{v:conv+"%",l:"Conversão",c:"#C9A96E"},{v:mV.length,l:"Visitas",c:"#8b5cf6"}].map((x,i)=>(
            <div key={i} className="pnum"><span style={{color:x.c}}>{x.v}</span><small>{x.l}</small></div>
          ))}
        </div>
      </div>
    </Modal>
  );
};

// ══════════════════════════════════════════════════════════
// DASHBOARD
// ══════════════════════════════════════════════════════════
const Dashboard = ({ leads, imoveis, visitas, user }) => {
  const admin = user.role==="admin";
  const mL = admin ? leads : leads.filter(l=>l.corretor===user.nome);
  const mV = admin ? visitas : visitas.filter(v=>v.corretor===user.nome);
  const ganhos = mL.filter(l=>l.status==="ganho");
  const ativos = mL.filter(l=>!["ganho","perdido"].includes(l.status));
  const conv   = mL.length ? Math.round(ganhos.length/mL.length*100) : 0;
  const hoje   = new Date().toISOString().split("T")[0];
  const kpis = [
    {l:admin?"Total Leads":"Meus Leads",v:mL.length,sub:`${ativos.length} ativos`,c:"#3b82f6",i:"users"},
    {l:"Imóveis",v:imoveis.length,sub:`${imoveis.filter(i=>i.status==="disponivel").length} disponíveis`,c:"#C9A96E",i:"build"},
    {l:"Fechamentos",v:ganhos.length,sub:`${conv}% de conversão`,c:"#10b981",i:"key"},
    {l:"Visitas Hoje",v:mV.filter(v=>v.data===hoje).length,sub:`${mV.filter(v=>v.status==="agendada").length} agendadas`,c:"#8b5cf6",i:"cal"},
  ];
  const pipeData = STATUS_LEAD.map(s=>({...s,n:mL.filter(l=>l.status===s.k).length}));
  const top5 = [...mL].sort((a,b)=>b.score-a.score).slice(0,5);
  const proxVis = mV.filter(v=>v.status==="agendada").sort((a,b)=>a.data.localeCompare(b.data)||a.hora.localeCompare(b.hora)).slice(0,4);
  const origemMap = {};
  mL.forEach(l=>{ origemMap[l.origem]=(origemMap[l.origem]||0)+1; });
  const origemArr = Object.entries(origemMap).sort((a,b)=>b[1]-a[1]).slice(0,6);

  return (
    <div className="page">
      <div className="page-hd">
        <div><h1>Olá, {user.nome.split(" ")[0]} 👋</h1><p className="page-sub">{admin?"Visão completa da equipe":"Seus resultados de hoje"}</p></div>
        <span className="today-badge">{new Date().toLocaleDateString("pt-BR",{weekday:"short",day:"2-digit",month:"short"})}</span>
      </div>
      <div className="kpi-grid">
        {kpis.map((k,i)=>(
          <div key={i} className="kpi-card" style={{"--kc":k.c}}>
            <div className="kpi-icon"><Ic n={k.i} s={20} c={k.c}/></div>
            <div className="kpi-val">{k.v}</div>
            <div className="kpi-label">{k.l}</div>
            <div className="kpi-sub">{k.sub}</div>
          </div>
        ))}
      </div>
      <div className="dash-cols">
        <div className="dcard wide">
          <div className="dcard-hd"><Ic n="funnel" s={15} c="#C9A96E"/>Pipeline</div>
          <div className="pipe-list">
            {pipeData.map(s=>(
              <div key={s.k} className="pipe-row">
                <span className="pipe-label" style={{color:s.c}}>{s.l}</span>
                <div className="pipe-track"><div className="pipe-fill" style={{width:`${mL.length?(s.n/mL.length)*100:0}%`,background:s.c}}/></div>
                <span className="pipe-n" style={{color:s.c}}>{s.n}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="dcard">
          <div className="dcard-hd"><Ic n="cal" s={15} c="#C9A96E"/>Próximas Visitas</div>
          <div className="vis-list">
            {proxVis.map(v=>(
              <div key={v.id} className="vis-row">
                <div className="vis-dt">
                  <b>{new Date(v.data+"T12:00").getDate()}</b>
                  <small>{new Date(v.data+"T12:00").toLocaleDateString("pt-BR",{month:"short"})}</small>
                  <span>{v.hora}</span>
                </div>
                <div className="vis-info"><div className="vis-nome">{v.lead}</div><div className="vis-im">{v.imovel}</div></div>
              </div>
            ))}
            {proxVis.length===0&&<p className="empty-txt">Sem visitas agendadas</p>}
          </div>
        </div>
      </div>
      <div className="dash-cols">
        <div className="dcard wide">
          <div className="dcard-hd"><Ic n="star" s={15} c="#C9A96E"/>Top Leads</div>
          <div className="top-list">
            {top5.map((l,i)=>(
              <div key={l.id} className="top-row">
                <span className="top-rank">#{i+1}</span>
                <Avatar nome={l.nome.slice(0,2)} cor={uObj[l.corretor]?.cor||"#C9A96E"} size={30} fontSize={11}/>
                <div className="top-info"><div className="top-nome">{l.nome}</div><div className="top-meta">{l.interesse} · {l.bairro} · {fmtM(l.orc)}</div></div>
                <Badge s={l.status}/>
                <div style={{minWidth:90}}><Score v={l.score}/></div>
              </div>
            ))}
            {top5.length===0&&<p className="empty-txt">Sem leads ainda</p>}
          </div>
        </div>
        <div className="dcard">
          <div className="dcard-hd"><Ic n="tag" s={15} c="#C9A96E"/>Origem dos Leads</div>
          <div className="origem-list">
            {origemArr.map(([o,n],i)=>(
              <div key={i} className="origem-row">
                <span className="origem-l">{o}</span>
                <div className="origem-t"><div className="origem-f" style={{width:`${(n/mL.length)*100}%`}}/></div>
                <span className="origem-n">{n}</span>
              </div>
            ))}
            {origemArr.length===0&&<p className="empty-txt">Sem dados</p>}
          </div>
        </div>
      </div>
      {admin&&(
        <div className="dcard" style={{marginTop:12}}>
          <div className="dcard-hd"><Ic n="team" s={15} c="#C9A96E"/>Desempenho da Equipe</div>
          <div className="equipe-wrap">
            <div className="eq-head"><span>Corretor</span><span>Leads</span><span>Ativos</span><span>Fechados</span><span>Conv.</span></div>
            {USERS.map(u=>{
              const ul=leads.filter(l=>l.corretor===u.nome);
              const ug=ul.filter(l=>l.status==="ganho");
              const ua=ul.filter(l=>!["ganho","perdido"].includes(l.status));
              const cv=ul.length?Math.round(ug.length/ul.length*100):0;
              return(
                <div key={u.id} className="eq-row">
                  <div className="eq-user"><Avatar nome={u.av} cor={u.cor} size={26} fontSize={9}/><div><div className="eq-nome">{u.nome}</div><div className="eq-cargo">{u.cargo}</div></div></div>
                  <span>{ul.length}</span><span style={{color:"#3b82f6"}}>{ua.length}</span><span style={{color:"#10b981"}}>{ug.length}</span><span style={{color:"#C9A96E"}}>{cv}%</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════
// LEADS PAGE
// ══════════════════════════════════════════════════════════
const LeadsPage = ({ leads, setLeads, user }) => {
  const admin = user.role==="admin";
  const [busca,setBusca] = useState("");
  const [fSt,setFSt]     = useState("todos");
  const [fCor,setFCor]   = useState(admin?"todos":user.nome);
  const [viewK,setViewK] = useState(false);
  const [modal,setModal] = useState(null);
  const [sel,setSel]     = useState(null);

  const base = admin ? leads : leads.filter(l=>l.corretor===user.nome);
  const list = base.filter(l=>{
    const m=busca.toLowerCase();
    return (!m||l.nome.toLowerCase().includes(m)||l.email?.toLowerCase().includes(m)||l.bairro?.toLowerCase().includes(m))
      &&(fSt==="todos"||l.status===fSt)
      &&(fCor==="todos"||l.corretor===fCor);
  });

  const save = (l) => { setLeads(p=>p.some(x=>x.id===l.id)?p.map(x=>x.id===l.id?l:x):[l,...p]); setModal(null); };
  const del  = ()  => { setLeads(p=>p.filter(l=>l.id!==sel.id)); setModal(null); };
  const move = (id,st) => setLeads(p=>p.map(l=>l.id===id?{...l,status:st}:l));
  const canEdit = l => admin||l.corretor===user.nome;

  return (
    <div className="page">
      <div className="page-hd">
        <div><h1>CRM — Leads</h1><p className="page-sub">{list.length} lead{list.length!==1?"s":""}</p></div>
        <div className="row gap8">
          <button className={`btn-tog${viewK?" on":""}`} onClick={()=>setViewK(!viewK)}>{viewK?"Lista":"Kanban"}</button>
          <button className="btn-gold" onClick={()=>{setSel(null);setModal("new");}}><Ic n="plus" s={15} c="#000"/> Novo Lead</button>
        </div>
      </div>
      <div className="filt-row">
        <div className="search-wrap"><Ic n="search" s={15} c="#555"/><input placeholder="Buscar..." value={busca} onChange={e=>setBusca(e.target.value)}/></div>
        <select value={fSt} onChange={e=>setFSt(e.target.value)}><option value="todos">Todos os status</option>{STATUS_LEAD.map(s=><option key={s.k} value={s.k}>{s.l}</option>)}</select>
        {admin&&<select value={fCor} onChange={e=>setFCor(e.target.value)}><option value="todos">Todos corretores</option>{USERS.map(u=><option key={u.id}>{u.nome}</option>)}</select>}
      </div>
      {viewK?(
        <div className="kanban">
          {STATUS_LEAD.map(col=>{
            const cl=list.filter(l=>l.status===col.k);
            return(
              <div key={col.k} className="kb-col">
                <div className="kb-col-hd" style={{borderColor:col.c}}><span style={{color:col.c,fontWeight:700,fontSize:12}}>{col.l}</span><span className="kb-cnt" style={{background:col.c+"20",color:col.c}}>{cl.length}</span></div>
                <div className="kb-cards">
                  {cl.map(l=>(
                    <div key={l.id} className="kb-card">
                      <div className="row gap8" style={{marginBottom:8}}>
                        <Avatar nome={l.nome.slice(0,2)} cor={uObj[l.corretor]?.cor} size={26} fontSize={10}/>
                        <div style={{flex:1,minWidth:0}}><div className="kb-nome">{l.nome}</div><div className="kb-meta">{l.origem}</div></div>
                      </div>
                      <div className="kb-orc">{fmtM(l.orc)}</div>
                      <div className="row gap4" style={{marginTop:6,flexWrap:"wrap"}}><span className="chip">{l.tipo}</span><span className="chip">{l.bairro}</span></div>
                      <div style={{margin:"8px 0"}}><Score v={l.score}/></div>
                      <div className="row gap4" style={{flexWrap:"wrap"}}>
                        <button className="ib gold" onClick={()=>{setSel(l);setModal("ai");}}><Ic n="ai" s={13} c="#C9A96E"/></button>
                        {canEdit(l)&&<button className="ib" onClick={()=>{setSel(l);setModal("edit");}}><Ic n="edit" s={13}/></button>}
                        {canEdit(l)&&<button className="ib red" onClick={()=>{setSel(l);setModal("del");}}><Ic n="trash" s={13}/></button>}
                        {canEdit(l)&&<select className="kb-sel" value={l.status} onChange={e=>move(l.id,e.target.value)}>{STATUS_LEAD.map(s=><option key={s.k} value={s.k}>{s.l}</option>)}</select>}
                      </div>
                    </div>
                  ))}
                  {cl.length===0&&<div className="kb-empty">Sem leads</div>}
                </div>
              </div>
            );
          })}
        </div>
      ):(
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>Lead</th><th>Contato</th><th>Interesse</th><th>Orçamento</th><th>Corretor</th><th>Status</th><th>Score</th><th></th></tr></thead>
            <tbody>
              {list.map(l=>(
                <tr key={l.id}>
                  <td><div className="row gap8"><Avatar nome={l.nome.slice(0,2)} cor={uObj[l.corretor]?.cor} size={32} fontSize={12}/><div><div className="t-nome">{l.nome}</div><div className="t-meta">{l.origem} · {fmtD(l.dt)}</div></div></div></td>
                  <td><div className="t-meta">{l.tel}</div><div className="t-meta">{l.email}</div></td>
                  <td><div>{l.interesse}</div><div className="t-meta">{l.tipo} · {l.bairro}</div></td>
                  <td className="t-money">{fmtM(l.orc)}</td>
                  <td><div className="row gap6"><Avatar nome={uObj[l.corretor]?.av||"?"} cor={uObj[l.corretor]?.cor||"#555"} size={22} fontSize={9}/><span style={{fontSize:12}}>{l.corretor.split(" ")[0]}</span></div></td>
                  <td><Badge s={l.status}/></td>
                  <td style={{minWidth:100}}><Score v={l.score}/></td>
                  <td><div className="row gap4">
                    <button className="ib gold" onClick={()=>{setSel(l);setModal("ai");}}><Ic n="ai" s={14} c="#C9A96E"/></button>
                    {canEdit(l)&&<button className="ib" onClick={()=>{setSel(l);setModal("edit");}}><Ic n="edit" s={14}/></button>}
                    {canEdit(l)&&<button className="ib red" onClick={()=>{setSel(l);setModal("del");}}><Ic n="trash" s={14}/></button>}
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {list.length===0&&<div className="tbl-empty"><Ic n="users" s={36} c="#333"/><p>Nenhum lead encontrado</p></div>}
        </div>
      )}
      {modal==="new"  && <FormLead onSave={save} onClose={()=>setModal(null)} user={user}/>}
      {modal==="edit" && <FormLead lead={sel} onSave={save} onClose={()=>setModal(null)} user={user}/>}
      {modal==="ai"   && <AIPanel lead={sel} onClose={()=>setModal(null)}/>}
      {modal==="del"  && <Confirm msg={`Excluir "${sel?.nome}"?`} onOk={del} onCancel={()=>setModal(null)}/>}
    </div>
  );
};

// ══════════════════════════════════════════════════════════
// PIPELINE
// ══════════════════════════════════════════════════════════
const PipelinePage = ({ leads, setLeads, user }) => {
  const admin = user.role==="admin";
  const [drag,setDrag] = useState(null);
  const [over,setOver] = useState(null);
  const mL = admin ? leads : leads.filter(l=>l.corretor===user.nome);
  const pot = mL.filter(l=>!["ganho","perdido"].includes(l.status)).reduce((a,l)=>a+(+l.orc||0),0);
  const drop = (st) => { if(drag) setLeads(p=>p.map(l=>l.id===drag?{...l,status:st}:l)); setDrag(null); setOver(null); };
  return (
    <div className="page">
      <div className="page-hd">
        <div><h1>Pipeline de Vendas</h1><p className="page-sub">Potencial: <b style={{color:"#C9A96E"}}>{fmtM(pot)}</b></p></div>
      </div>
      <div className="pipe-board">
        {STATUS_LEAD.map(col=>{
          const cl=mL.filter(l=>l.status===col.k);
          const tot=cl.reduce((a,l)=>a+(+l.orc||0),0);
          return(
            <div key={col.k} className={`pb-col${over===col.k?" pb-over":""}`}
              onDragOver={e=>{e.preventDefault();setOver(col.k);}} onDrop={()=>drop(col.k)} onDragLeave={()=>setOver(null)}>
              <div className="pb-hd" style={{borderBottom:`2px solid ${col.c}`}}>
                <span style={{color:col.c,fontWeight:700,fontSize:12}}>{col.l}</span>
                <div className="row gap6"><span className="pb-cnt" style={{background:col.c+"20",color:col.c}}>{cl.length}</span>{tot>0&&<span style={{fontSize:10,color:"#555"}}>{fmtM(tot)}</span>}</div>
              </div>
              <div className="pb-cards">
                {cl.map(l=>(
                  <div key={l.id} className="pb-card" draggable={admin||l.corretor===user.nome} onDragStart={()=>setDrag(l.id)} onDragEnd={()=>{setDrag(null);setOver(null);}}>
                    <div className="row gap8" style={{marginBottom:6}}>
                      <Avatar nome={l.nome.slice(0,2)} cor={uObj[l.corretor]?.cor} size={24} fontSize={9}/>
                      <div style={{flex:1,minWidth:0}}><div className="pb-nome">{l.nome}</div><div className="pb-meta">{l.corretor.split(" ")[0]}</div></div>
                    </div>
                    <div className="pb-orc">{fmtM(l.orc)}</div>
                    <div className="row gap4" style={{marginTop:5,flexWrap:"wrap"}}><span className="chip">{l.tipo}</span><span className="chip gold">{l.origem}</span></div>
                    <div style={{marginTop:6}}><Score v={l.score}/></div>
                  </div>
                ))}
                {cl.length===0&&<div className="pb-empty">Arraste aqui</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════
// IMÓVEIS
// ══════════════════════════════════════════════════════════
const ImoveisPage = ({ imoveis, setImoveis, user }) => {
  const admin = user.role==="admin";
  const [busca,setBusca] = useState("");
  const [fFin,setFFin]   = useState("todos");
  const [fSt,setFSt]     = useState("todos");
  const [modal,setModal] = useState(null);
  const [sel,setSel]     = useState(null);
  const [viewG,setViewG] = useState(true);
  const list = imoveis.filter(im=>{
    const m=busca.toLowerCase();
    return (!m||im.titulo.toLowerCase().includes(m)||im.bairro?.toLowerCase().includes(m))
      &&(fFin==="todos"||im.fin===fFin)&&(fSt==="todos"||im.status===fSt);
  });
  const save = (im) => { setImoveis(p=>p.some(x=>x.id===im.id)?p.map(x=>x.id===im.id?im:x):[im,...p]); setModal(null); };
  const del  = ()   => { setImoveis(p=>p.filter(i=>i.id!==sel.id)); setModal(null); };
  const canE = im   => admin||im.corretor===user.nome;
  const stCfg={disponivel:{l:"Disponível",c:"#10b981"},reservado:{l:"Reservado",c:"#f59e0b"},negociacao:{l:"Em Negociação",c:"#ec4899"},vendido:{l:"Vendido",c:"#6b7280"}};
  return (
    <div className="page">
      <div className="page-hd">
        <div><h1>Imóveis</h1><p className="page-sub">{list.length} imóvel(eis)</p></div>
        <div className="row gap8">
          <button className={`btn-tog${viewG?" on":""}`} onClick={()=>setViewG(!viewG)}><Ic n={viewG?"list":"grid"} s={16}/></button>
          <button className="btn-gold" onClick={()=>{setSel(null);setModal("new");}}><Ic n="plus" s={15} c="#000"/> Novo Imóvel</button>
        </div>
      </div>
      <div className="filt-row">
        <div className="search-wrap"><Ic n="search" s={15} c="#555"/><input placeholder="Buscar..." value={busca} onChange={e=>setBusca(e.target.value)}/></div>
        <select value={fFin} onChange={e=>setFFin(e.target.value)}><option value="todos">Venda + Aluguel</option><option value="Venda">Venda</option><option value="Aluguel">Aluguel</option></select>
        <select value={fSt} onChange={e=>setFSt(e.target.value)}><option value="todos">Todos status</option><option value="disponivel">Disponível</option><option value="reservado">Reservado</option><option value="negociacao">Negociação</option><option value="vendido">Vendido</option></select>
      </div>
      {viewG?(
        <div className="im-grid">
          {list.map(im=>{const st=stCfg[im.status]||{l:im.status,c:"#888"};return(
            <div key={im.id} className="im-card">
              <div className="im-img">
                {im.foto?<img src={im.foto} alt={im.titulo} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                        :<div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100%"}}><Ic n="build" s={28} c="#333"/></div>}
                <span className="im-fin" style={{background:im.fin==="Venda"?"#C9A96E":"#10b981",color:"#000"}}>{im.fin}</span>
                <span className="im-st" style={{background:st.c+"22",color:st.c,border:`1px solid ${st.c}44`}}>{st.l}</span>
                <span className="im-cod">{im.cod}</span>
              </div>
              <div className="im-body">
                <div className="im-tp">{im.tipo}</div>
                <div className="im-titulo">{im.titulo}</div>
                <div className="row gap4" style={{margin:"4px 0 10px"}}><Ic n="pin" s={11} c="#C9A96E"/><span style={{fontSize:11,color:"#666"}}>{im.bairro}</span></div>
                <div className="im-specs">
                  {im.area>0&&<span>{im.area}m²</span>}
                  {im.qts>0&&<span><Ic n="bed" s={11}/> {im.qts}</span>}
                  {im.bhs>0&&<span>{im.bhs}bh</span>}
                  {im.vgs>0&&<span><Ic n="car" s={11}/> {im.vgs}</span>}
                </div>
                <div className="im-footer">
                  <div className="im-preco">{im.fin==="Aluguel"?`R$ ${(+im.preco).toLocaleString("pt-BR")}/mês`:fmtM(+im.preco)}</div>
                  {canE(im)&&<div className="row gap4"><button className="ib" onClick={()=>{setSel(im);setModal("edit");}}><Ic n="edit" s={14}/></button><button className="ib red" onClick={()=>{setSel(im);setModal("del");}}><Ic n="trash" s={14}/></button></div>}
                </div>
                <div className="im-cor"><Ic n="key" s={11} c="#C9A96E"/> {im.corretor}</div>
              </div>
            </div>
          );})}
          {list.length===0&&<div className="tbl-empty" style={{gridColumn:"1/-1"}}><Ic n="build" s={36} c="#333"/><p>Nenhum imóvel</p></div>}
        </div>
      ):(
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>Imóvel</th><th>Tipo</th><th>Bairro</th><th>Preço</th><th>Status</th><th>Corretor</th><th></th></tr></thead>
            <tbody>{list.map(im=>{const st=stCfg[im.status]||{l:im.status,c:"#888"};return(
              <tr key={im.id}>
                <td><div className="t-nome">{im.titulo}</div><div className="t-meta">{im.cod} · {im.fin}</div></td>
                <td>{im.tipo}</td><td>{im.bairro}</td>
                <td className="t-money">{im.fin==="Aluguel"?`R$ ${(+im.preco).toLocaleString("pt-BR")}/mês`:fmtM(+im.preco)}</td>
                <td><span style={{background:st.c+"20",color:st.c,border:`1px solid ${st.c}35`,padding:"2px 8px",borderRadius:99,fontSize:11,fontWeight:700}}>{st.l}</span></td>
                <td><div className="row gap6"><Avatar nome={uObj[im.corretor]?.av||"?"} cor={uObj[im.corretor]?.cor||"#555"} size={22} fontSize={9}/><span style={{fontSize:12}}>{im.corretor.split(" ")[0]}</span></div></td>
                <td>{canE(im)&&<div className="row gap4"><button className="ib" onClick={()=>{setSel(im);setModal("edit");}}><Ic n="edit" s={14}/></button><button className="ib red" onClick={()=>{setSel(im);setModal("del");}}><Ic n="trash" s={14}/></button></div>}</td>
              </tr>
            );})}</tbody>
          </table>
        </div>
      )}
      {modal==="new"  && <FormImovel onSave={save} onClose={()=>setModal(null)} user={user}/>}
      {modal==="edit" && <FormImovel im={sel} onSave={save} onClose={()=>setModal(null)} user={user}/>}
      {modal==="del"  && <Confirm msg={`Excluir "${sel?.titulo}"?`} onOk={del} onCancel={()=>setModal(null)}/>}
    </div>
  );
};

// ══════════════════════════════════════════════════════════
// AGENDA
// ══════════════════════════════════════════════════════════
const AgendaPage = ({ visitas, setVisitas, leads, imoveis, user }) => {
  const admin = user.role==="admin";
  const [modal,setModal] = useState(false);
  const [fDt,setFDt]     = useState("");
  const [fSt,setFSt]     = useState("todos");
  const mV = admin ? visitas : visitas.filter(v=>v.corretor===user.nome);
  const list = mV.filter(v=>(!fDt||v.data===fDt)&&(fSt==="todos"||v.status===fSt)).sort((a,b)=>a.data.localeCompare(b.data)||a.hora.localeCompare(b.hora));
  const save = (v) => { setVisitas(p=>[v,...p]); setModal(false); };
  const upd  = (id,st) => setVisitas(p=>p.map(v=>v.id===id?{...v,status:st}:v));
  const del  = (id) => setVisitas(p=>p.filter(v=>v.id!==id));
  const canA = v => admin||v.corretor===user.nome;
  const stV={agendada:{l:"Agendada",c:"#3b82f6"},realizada:{l:"Realizada",c:"#10b981"},cancelada:{l:"Cancelada",c:"#ef4444"}};
  return (
    <div className="page">
      <div className="page-hd">
        <div><h1>Agenda de Visitas</h1><p className="page-sub">{mV.filter(v=>v.status==="agendada").length} agendadas</p></div>
        <button className="btn-gold" onClick={()=>setModal(true)}><Ic n="plus" s={15} c="#000"/> Agendar Visita</button>
      </div>
      <div className="filt-row">
        <input type="date" value={fDt} onChange={e=>setFDt(e.target.value)} style={{background:"#161616",border:"1px solid #222",borderRadius:8,padding:"8px 12px",color:"#fff",fontSize:13,width:"auto"}}/>
        <select value={fSt} onChange={e=>setFSt(e.target.value)} style={{width:"auto"}}><option value="todos">Todos</option><option value="agendada">Agendadas</option><option value="realizada">Realizadas</option><option value="cancelada">Canceladas</option></select>
        {fDt&&<button className="btn-ghost sm" onClick={()=>setFDt("")}>Limpar</button>}
      </div>
      <div className="agt-list">
        {list.map(v=>{
          const st=stV[v.status]||{l:v.status,c:"#888"};
          const d=new Date(v.data+"T12:00");
          return(
            <div key={v.id} className="agt-card" style={{borderLeft:`3px solid ${st.c}`}}>
              <div className="agt-dt"><b>{d.getDate()}</b><small>{d.toLocaleDateString("pt-BR",{month:"short"})}</small><span>{v.hora}</span></div>
              <div className="agt-info">
                <div className="agt-lead">{v.lead}</div>
                <div className="agt-im"><Ic n="build" s={12} c="#C9A96E"/> {v.imovel}</div>
                <div className="agt-cor"><Avatar nome={uObj[v.corretor]?.av||"?"} cor={uObj[v.corretor]?.cor||"#555"} size={18} fontSize={8}/>{v.corretor}</div>
                {v.obs&&<div className="agt-obs">"{v.obs}"</div>}
              </div>
              <div className="agt-right">
                <span style={{background:st.c+"20",color:st.c,border:`1px solid ${st.c}35`,padding:"2px 10px",borderRadius:99,fontSize:11,fontWeight:700}}>{st.l}</span>
                {canA(v)&&<div className="row gap4 wrap">
                  {v.status==="agendada"&&<><button className="btn-sm green" onClick={()=>upd(v.id,"realizada")}>✓ Realizada</button><button className="btn-sm red" onClick={()=>upd(v.id,"cancelada")}>✗ Cancelar</button></>}
                  <button className="ib red" onClick={()=>del(v.id)}><Ic n="trash" s={13}/></button>
                </div>}
              </div>
            </div>
          );
        })}
        {list.length===0&&<div className="tbl-empty"><Ic n="cal" s={36} c="#333"/><p>Nenhuma visita</p></div>}
      </div>
      {modal&&<FormVisita onSave={save} onClose={()=>setModal(false)} leads={leads} imoveis={imoveis} user={user}/>}
    </div>
  );
};

// ══════════════════════════════════════════════════════════
// APP ROOT
// ══════════════════════════════════════════════════════════
export default function App() {
  const [user,setUser]       = useState(null);
  const [pag,setPag]         = useState("dash");
  const [leads,setLeads]     = useState(LEADS0);
  const [imoveis,setImoveis] = useState(IMOVEIS0);
  const [visitas,setVisitas] = useState(VISITAS0);
  const [sideOpen,setSide]   = useState(false);
  const [uMenu,setUMenu]     = useState(false);
  const [perfil,setPerfil]   = useState(false);

  if (!user) return (
    <>
      <style>{CSS}</style>
      <Login onLogin={u=>{setUser(u);setPag("dash");}}/>
    </>
  );

  const admin = user.role==="admin";
  const nav = [
    {id:"dash",    l:"Dashboard",   i:"home"},
    {id:"leads",   l:"CRM / Leads", i:"users"},
    {id:"pipeline",l:"Pipeline",    i:"funnel"},
    {id:"imoveis", l:"Imóveis",     i:"build"},
    {id:"agenda",  l:"Agenda",      i:"cal"},
  ];
  const cnt = {
    leads:   leads.length,
    agenda:  visitas.filter(v=>v.status==="agendada"&&(admin||v.corretor===user.nome)).length,
    imoveis: imoveis.length,
  };

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <aside className={`sb${sideOpen?" open":""}`}>
          <div className="sb-brand">
            <div className="sb-mark">A</div>
            <div><p className="sb-eye">ALTERNATIVA</p><p className="sb-name">IMOB<span>X</span></p></div>
          </div>
          <nav className="sb-nav">
            <p className="sb-sec">MENU</p>
            {nav.map(n=>(
              <button key={n.id} className={`sb-lnk${pag===n.id?" on":""}`} onClick={()=>{setPag(n.id);setSide(false);}}>
                <Ic n={n.i} s={17} c={pag===n.id?"#C9A96E":"#555"}/>
                <span>{n.l}</span>
                {cnt[n.id]!==undefined&&<span className="sb-cnt">{cnt[n.id]}</span>}
              </button>
            ))}
          </nav>
          <button className="sb-user" onClick={()=>{setUMenu(!uMenu);setSide(false);}}>
            <Avatar nome={user.av} cor={user.cor} size={30} fontSize={11}/>
            <div style={{flex:1,textAlign:"left",minWidth:0}}><div className="sb-uname">{user.nome}</div><div className="sb-urole">{user.cargo}</div></div>
            {admin&&<Ic n="shield" s={12} c="#C9A96E"/>}
          </button>
        </aside>
        {sideOpen&&<div className="sb-ov" onClick={()=>setSide(false)}/>}

        {uMenu&&(
          <div className="umenu-ov" onClick={()=>setUMenu(false)}>
            <div className="umenu" onClick={e=>e.stopPropagation()}>
              <div className="umenu-top">
                <Avatar nome={user.av} cor={user.cor} size={38} fontSize={13}/>
                <div><div className="umenu-nome">{user.nome}</div><div className="umenu-email">{user.email}</div>
                  {admin&&<span className="admin-chip"><Ic n="shield" s={10} c="#C9A96E"/> Admin</span>}
                </div>
              </div>
              <div className="umenu-sep"/>
              <button className="umenu-item" onClick={()=>{setPerfil(true);setUMenu(false);}}><Ic n="user" s={15}/>Meu Perfil</button>
              <div className="umenu-sep"/>
              <button className="umenu-item red" onClick={()=>{setUser(null);setUMenu(false);}}><Ic n="logout" s={15} c="#ef4444"/>Sair do sistema</button>
            </div>
          </div>
        )}

        <div className="main">
          <header className="topbar">
            <button className="mob-menu" onClick={()=>setSide(!sideOpen)}><Ic n="menu" s={22}/></button>
            <span className="tb-title">{nav.find(n=>n.id===pag)?.l}</span>
            <button className="tb-av" style={{background:user.cor}} onClick={()=>setUMenu(!uMenu)}>{user.av}</button>
          </header>
          <div className="content">
            {pag==="dash"     && <Dashboard  leads={leads} imoveis={imoveis} visitas={visitas} user={user}/>}
            {pag==="leads"    && <LeadsPage  leads={leads} setLeads={setLeads} user={user}/>}
            {pag==="pipeline" && <PipelinePage leads={leads} setLeads={setLeads} user={user}/>}
            {pag==="imoveis"  && <ImoveisPage imoveis={imoveis} setImoveis={setImoveis} user={user}/>}
            {pag==="agenda"   && <AgendaPage visitas={visitas} setVisitas={setVisitas} leads={leads} imoveis={imoveis} user={user}/>}
          </div>
        </div>

        <nav className="mob-nav">
          {nav.map(n=>(
            <button key={n.id} className={`mn-btn${pag===n.id?" on":""}`} onClick={()=>setPag(n.id)}>
              <Ic n={n.i} s={20} c={pag===n.id?"#C9A96E":"#444"}/>
              <span>{n.l.split(" ")[0]}</span>
              {cnt[n.id]>0&&<span className="mn-dot"/>}
            </button>
          ))}
        </nav>
      </div>
      {perfil&&<PerfilModal user={user} leads={leads} visitas={visitas} onClose={()=>setPerfil(false)}/>}
    </>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,700;12..96,800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{--g:#C9A96E;--g2:#e8d5b0;--g3:#8a6d38;--bg:#080808;--sb:#0e0e0e;--card:#131313;--card2:#1a1a1a;--card3:#202020;--b1:#1e1e1e;--b2:#282828;--b3:#333;--t1:#efefef;--t2:#888;--t3:#4a4a4a;--r:10px;--shadow:0 8px 32px rgba(0,0,0,.6);}
html,body{height:100%;background:var(--bg);color:var(--t1);font-family:'DM Sans',sans-serif;font-size:14px;line-height:1.5;overflow:hidden;}
h1{font-family:'Bricolage Grotesque',sans-serif;font-size:22px;font-weight:700;color:#fff;line-height:1.2;}
h2,h3{font-family:'Bricolage Grotesque',sans-serif;font-weight:700;color:#fff;}
button{cursor:pointer;background:none;border:none;font-family:inherit;font-size:14px;color:var(--t1);}
input,select,textarea{font-family:inherit;font-size:13px;color:var(--t1);background:var(--card2);border:1px solid var(--b2);border-radius:8px;padding:9px 11px;outline:none;width:100%;transition:border-color .2s;}
input:focus,select:focus,textarea:focus{border-color:rgba(201,169,110,.45);}
input[type=date]::-webkit-calendar-picker-indicator{filter:invert(.4);}
select option{background:#181818;}
textarea{resize:vertical;}
a{color:var(--t2);text-decoration:none;}
img{display:block;}
small{font-size:11px;}
.app{display:flex;height:100vh;overflow:hidden;position:relative;}
.main{flex:1;display:flex;flex-direction:column;min-width:0;overflow:hidden;}
.content{flex:1;overflow-y:auto;padding-bottom:16px;}
.sb{width:220px;min-width:220px;background:var(--sb);border-right:1px solid var(--b1);display:flex;flex-direction:column;z-index:300;transition:transform .28s cubic-bezier(.4,0,.2,1);}
.sb-ov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:299;}
.sb-brand{padding:18px 16px;display:flex;align-items:center;gap:10px;border-bottom:1px solid var(--b1);}
.sb-mark{width:32px;height:32px;background:var(--g);border-radius:8px;display:flex;align-items:center;justify-content:center;font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:17px;color:#000;flex-shrink:0;}
.sb-eye{font-size:8px;letter-spacing:2.5px;color:var(--g);font-weight:600;line-height:1.2;}
.sb-name{font-family:'Bricolage Grotesque',sans-serif;font-size:15px;font-weight:800;color:#fff;letter-spacing:.5px;}
.sb-name span{color:var(--g);}
.sb-nav{flex:1;padding:14px 10px;display:flex;flex-direction:column;gap:1px;}
.sb-sec{font-size:9px;letter-spacing:2px;color:var(--t3);padding:4px 8px 6px;text-transform:uppercase;}
.sb-lnk{display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:8px;color:var(--t3);transition:all .18s;text-align:left;font-size:13px;font-weight:500;}
.sb-lnk:hover{background:rgba(255,255,255,.04);color:var(--t1);}
.sb-lnk.on{background:rgba(201,169,110,.1);color:var(--g);border:1px solid rgba(201,169,110,.18);}
.sb-cnt{margin-left:auto;background:rgba(201,169,110,.15);color:var(--g);border-radius:99px;padding:1px 7px;font-size:10px;font-weight:700;}
.sb-user{display:flex;align-items:center;gap:9px;padding:12px 12px;border-top:1px solid var(--b1);transition:background .18s;text-align:left;width:100%;}
.sb-user:hover{background:var(--card);}
.sb-uname{font-size:12px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sb-urole{font-size:10px;color:var(--t3);}
.topbar{height:52px;background:var(--sb);border-bottom:1px solid var(--b1);display:flex;align-items:center;padding:0 16px;gap:10px;flex-shrink:0;}
.tb-title{font-family:'Bricolage Grotesque',sans-serif;font-size:15px;font-weight:700;color:#fff;flex:1;}
.tb-av{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#000;cursor:pointer;flex-shrink:0;margin-left:auto;}
.mob-menu{width:36px;height:36px;display:none;align-items:center;justify-content:center;border-radius:8px;color:var(--t2);}
.mob-nav{display:none;position:fixed;bottom:0;left:0;right:0;height:60px;background:var(--sb);border-top:1px solid var(--b1);z-index:400;}
.mn-btn{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:6px 0;font-size:9px;color:var(--t3);transition:color .18s;position:relative;}
.mn-btn.on{color:var(--g);}
.mn-dot{position:absolute;top:8px;right:calc(50% - 14px);width:5px;height:5px;border-radius:50%;background:#ef4444;}
.umenu-ov{position:fixed;inset:0;z-index:500;}
.umenu{position:fixed;bottom:64px;left:12px;width:252px;background:var(--card2);border:1px solid var(--b2);border-radius:12px;box-shadow:var(--shadow);z-index:501;overflow:hidden;animation:fadeUp .16s ease;}
@keyframes fadeUp{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}
.umenu-top{padding:14px 16px;display:flex;align-items:center;gap:10px;}
.umenu-nome{font-size:14px;font-weight:600;color:#fff;}
.umenu-email{font-size:11px;color:var(--t2);}
.umenu-sep{height:1px;background:var(--b1);}
.umenu-item{display:flex;align-items:center;gap:10px;padding:11px 16px;width:100%;font-size:13px;color:var(--t2);transition:all .18s;}
.umenu-item:hover{background:var(--card3);color:#fff;}
.umenu-item.red{color:#ef4444;}
.umenu-item.red:hover{background:rgba(239,68,68,.08);}
.admin-chip{display:inline-flex;align-items:center;gap:4px;font-size:10px;color:var(--g);background:rgba(201,169,110,.1);padding:2px 7px;border-radius:4px;margin-top:4px;}
.page{padding:20px;max-width:1400px;margin:0 auto;}
.page-hd{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:20px;}
.page-sub{font-size:12px;color:var(--t2);margin-top:2px;}
.today-badge{font-size:12px;color:var(--t2);text-transform:capitalize;white-space:nowrap;}
.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px;}
.kpi-card{background:var(--card);border:1px solid var(--b1);border-radius:var(--r);padding:16px;transition:border-color .2s;}
.kpi-card:hover{border-color:rgba(201,169,110,.2);}
.kpi-icon{width:40px;height:40px;border-radius:10px;background:color-mix(in srgb,var(--kc) 14%,transparent);display:flex;align-items:center;justify-content:center;margin-bottom:10px;}
.kpi-val{font-family:'Bricolage Grotesque',sans-serif;font-size:26px;font-weight:700;color:#fff;line-height:1;}
.kpi-label{font-size:12px;color:var(--t2);margin:3px 0 2px;}
.kpi-sub{font-size:11px;color:var(--g);}
.dash-cols{display:grid;grid-template-columns:1.5fr 1fr;gap:12px;margin-bottom:12px;}
.dcard{background:var(--card);border:1px solid var(--b1);border-radius:var(--r);padding:16px;}
.dcard-hd{display:flex;align-items:center;gap:7px;font-weight:600;font-size:13px;color:#fff;margin-bottom:14px;}
.pipe-list{display:flex;flex-direction:column;gap:8px;}
.pipe-row{display:grid;grid-template-columns:120px 1fr 24px;align-items:center;gap:8px;}
.pipe-label{font-size:11px;}
.pipe-track{height:4px;background:#1e1e1e;border-radius:99px;overflow:hidden;}
.pipe-fill{height:100%;border-radius:99px;transition:width .6s;}
.pipe-n{font-size:11px;font-weight:700;text-align:right;}
.vis-list{display:flex;flex-direction:column;gap:7px;}
.vis-row{display:flex;align-items:center;gap:10px;padding:8px;background:var(--card2);border-radius:8px;}
.vis-dt{text-align:center;min-width:38px;}
.vis-dt b{display:block;font-family:'Bricolage Grotesque',sans-serif;font-size:20px;color:var(--g);line-height:1;}
.vis-dt small{display:block;font-size:9px;color:var(--t3);text-transform:uppercase;}
.vis-dt span{font-size:10px;color:var(--t2);margin-top:1px;display:block;}
.vis-info{flex:1;min-width:0;}
.vis-nome{font-size:12px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.vis-im{font-size:10px;color:var(--t2);}
.top-list{display:flex;flex-direction:column;gap:7px;}
.top-row{display:flex;align-items:center;gap:8px;padding:8px;background:var(--card2);border-radius:8px;}
.top-rank{font-size:10px;color:var(--t3);font-weight:700;min-width:18px;}
.top-info{flex:1;min-width:0;}
.top-nome{font-size:12px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.top-meta{font-size:10px;color:var(--t2);}
.origem-list{display:flex;flex-direction:column;gap:7px;}
.origem-row{display:flex;align-items:center;gap:8px;}
.origem-l{font-size:11px;color:var(--t2);min-width:72px;}
.origem-t{flex:1;height:4px;background:#1e1e1e;border-radius:99px;overflow:hidden;}
.origem-f{height:100%;background:var(--g);border-radius:99px;}
.origem-n{font-size:11px;font-weight:700;min-width:18px;text-align:right;}
.equipe-wrap{display:flex;flex-direction:column;}
.eq-head{display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;padding:7px 12px;font-size:10px;letter-spacing:.8px;text-transform:uppercase;color:var(--t3);border-bottom:1px solid var(--b1);}
.eq-row{display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;align-items:center;padding:9px 12px;border-bottom:1px solid var(--b1);font-size:12px;font-weight:600;}
.eq-row:last-child{border-bottom:none;}
.eq-row:hover{background:rgba(255,255,255,.02);}
.eq-user{display:flex;align-items:center;gap:7px;}
.eq-nome{font-size:12px;font-weight:600;color:#fff;}
.eq-cargo{font-size:10px;color:var(--t3);}
.empty-txt{font-size:12px;color:var(--t3);text-align:center;padding:16px 0;}
.filt-row{display:flex;align-items:center;gap:8px;margin-bottom:16px;flex-wrap:wrap;}
.filt-row select{width:auto;flex-shrink:0;}
.search-wrap{display:flex;align-items:center;gap:7px;background:var(--card);border:1px solid var(--b1);border-radius:8px;padding:0 10px;flex:1;min-width:160px;}
.search-wrap input{background:none;border:none;padding:8px 0;}
.btn-gold{display:flex;align-items:center;gap:6px;padding:8px 15px;background:var(--g);color:#000;border-radius:8px;font-size:13px;font-weight:700;transition:background .2s;white-space:nowrap;}
.btn-gold:hover{background:var(--g2);}
.btn-ghost{padding:8px 14px;border-radius:8px;font-size:13px;color:var(--t2);border:1px solid var(--b1);transition:all .18s;}
.btn-ghost:hover{color:#fff;border-color:var(--b3);}
.btn-ghost.sm{padding:6px 10px;font-size:12px;}
.btn-danger{display:flex;align-items:center;gap:6px;padding:8px 14px;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.28);color:#ef4444;border-radius:8px;font-size:13px;font-weight:700;transition:all .18s;}
.btn-danger:hover{background:rgba(239,68,68,.22);}
.btn-tog{padding:8px 13px;border-radius:8px;font-size:13px;font-weight:600;color:var(--t2);border:1px solid var(--b1);transition:all .18s;}
.btn-tog.on{background:var(--card2);color:#fff;border-color:var(--b2);}
.btn-sm{padding:4px 9px;border-radius:6px;font-size:11px;font-weight:700;border:1px solid transparent;transition:all .18s;cursor:pointer;}
.btn-sm.green{color:#10b981;border-color:#10b98130;background:#10b98112;}
.btn-sm.green:hover{background:#10b98125;}
.btn-sm.red{color:#ef4444;border-color:#ef444430;background:#ef444412;}
.btn-sm.red:hover{background:#ef444425;}
.ib{width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;color:var(--t2);transition:all .18s;flex-shrink:0;}
.ib:hover{background:var(--card2);color:#fff;}
.ib.gold{color:var(--g)!important;}
.ib.gold:hover{background:rgba(201,169,110,.1);}
.ib.red:hover{color:#ef4444;}
.tbl-wrap{background:var(--card);border:1px solid var(--b1);border-radius:var(--r);overflow-x:auto;}
.tbl{width:100%;border-collapse:collapse;}
.tbl th{padding:10px 13px;text-align:left;font-size:10px;letter-spacing:.8px;text-transform:uppercase;color:var(--t3);border-bottom:1px solid var(--b1);background:var(--card2);white-space:nowrap;}
.tbl td{padding:10px 13px;border-bottom:1px solid var(--b1);vertical-align:middle;}
.tbl tr:last-child td{border-bottom:none;}
.tbl tr:hover td{background:rgba(255,255,255,.018);}
.t-nome{font-size:13px;font-weight:600;color:#fff;}
.t-meta{font-size:11px;color:var(--t3);margin-top:1px;}
.t-money{font-family:'Bricolage Grotesque',sans-serif;font-size:13px;font-weight:700;color:var(--g);}
.tbl-empty{display:flex;flex-direction:column;align-items:center;gap:10px;padding:48px;color:var(--t3);}
.kanban{display:flex;gap:9px;overflow-x:auto;padding-bottom:12px;}
.kb-col{min-width:196px;background:var(--card);border:1px solid var(--b1);border-radius:var(--r);display:flex;flex-direction:column;flex-shrink:0;}
.kb-col-hd{padding:10px 11px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--b1);}
.kb-cnt{padding:1px 7px;border-radius:99px;font-size:10px;font-weight:700;}
.kb-cards{flex:1;padding:8px;display:flex;flex-direction:column;gap:6px;overflow-y:auto;max-height:460px;}
.kb-card{background:var(--card2);border:1px solid var(--b2);border-radius:8px;padding:10px;display:flex;flex-direction:column;}
.kb-card:hover{border-color:rgba(201,169,110,.22);}
.kb-nome{font-size:12px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.kb-meta{font-size:10px;color:var(--t3);}
.kb-orc{font-family:'Bricolage Grotesque',sans-serif;font-size:14px;font-weight:700;color:var(--g);}
.kb-empty{font-size:11px;color:var(--t3);text-align:center;padding:14px 8px;border:1px dashed var(--b1);border-radius:7px;}
.kb-sel{width:auto;flex:1;padding:4px 6px;font-size:10px;border-radius:5px;}
.pipe-board{display:flex;gap:10px;overflow-x:auto;padding-bottom:12px;min-height:420px;}
.pb-col{min-width:186px;width:186px;background:var(--card);border:1px solid var(--b1);border-radius:var(--r);display:flex;flex-direction:column;flex-shrink:0;transition:background .18s,border-color .18s;}
.pb-over{background:rgba(201,169,110,.05);border-color:rgba(201,169,110,.28);}
.pb-hd{padding:9px 11px;display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;}
.pb-cnt{padding:1px 6px;border-radius:99px;font-size:10px;font-weight:700;}
.pb-cards{flex:1;padding:7px;display:flex;flex-direction:column;gap:6px;overflow-y:auto;}
.pb-card{background:var(--card2);border:1px solid var(--b2);border-radius:8px;padding:9px;cursor:grab;user-select:none;transition:border-color .18s;}
.pb-card:active{cursor:grabbing;opacity:.8;}
.pb-card:hover{border-color:rgba(201,169,110,.22);}
.pb-nome{font-size:11px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pb-meta{font-size:9px;color:var(--t3);}
.pb-orc{font-family:'Bricolage Grotesque',sans-serif;font-size:13px;font-weight:700;color:var(--g);margin-top:4px;}
.pb-empty{font-size:10px;color:var(--t3);text-align:center;padding:14px 6px;border:1px dashed var(--b1);border-radius:6px;}
.im-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(256px,1fr));gap:14px;}
.im-card{background:var(--card);border:1px solid var(--b1);border-radius:var(--r);overflow:hidden;transition:transform .22s,box-shadow .22s;}
.im-card:hover{transform:translateY(-3px);box-shadow:0 10px 32px rgba(0,0,0,.45);}
.im-img{position:relative;aspect-ratio:16/10;overflow:hidden;background:var(--card2);}
.im-img img{transition:transform .4s;width:100%;height:100%;object-fit:cover;}
.im-card:hover .im-img img{transform:scale(1.05);}
.im-fin{position:absolute;top:8px;left:8px;padding:3px 9px;border-radius:5px;font-size:10px;font-weight:800;}
.im-st{position:absolute;top:8px;right:8px;padding:3px 8px;border-radius:5px;font-size:10px;font-weight:700;}
.im-cod{position:absolute;bottom:7px;left:8px;background:rgba(0,0,0,.72);color:#fff;padding:2px 6px;border-radius:4px;font-size:9px;letter-spacing:.5px;}
.im-body{padding:12px;}
.im-tp{font-size:9px;letter-spacing:1.5px;text-transform:uppercase;color:var(--g);margin-bottom:2px;}
.im-titulo{font-family:'Bricolage Grotesque',sans-serif;font-size:14px;font-weight:700;color:#fff;margin-bottom:2px;line-height:1.3;}
.im-specs{display:flex;gap:8px;flex-wrap:wrap;padding:7px 0;border-top:1px solid var(--b1);border-bottom:1px solid var(--b1);margin-bottom:8px;}
.im-specs span{display:flex;align-items:center;gap:3px;font-size:11px;color:var(--t2);}
.im-footer{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;}
.im-preco{font-family:'Bricolage Grotesque',sans-serif;font-size:15px;font-weight:700;color:var(--g);}
.im-cor{font-size:10px;color:var(--t3);display:flex;align-items:center;gap:4px;}
.agt-list{display:flex;flex-direction:column;gap:9px;}
.agt-card{background:var(--card);border:1px solid var(--b1);border-left-width:3px;border-radius:var(--r);padding:13px 15px;display:flex;align-items:flex-start;gap:14px;}
.agt-dt{text-align:center;min-width:42px;flex-shrink:0;}
.agt-dt b{display:block;font-family:'Bricolage Grotesque',sans-serif;font-size:24px;color:var(--g);line-height:1;}
.agt-dt small{display:block;font-size:9px;color:var(--t3);text-transform:uppercase;}
.agt-dt span{display:block;font-size:11px;color:var(--t2);margin-top:2px;}
.agt-info{flex:1;min-width:0;}
.agt-lead{font-size:14px;font-weight:600;color:#fff;margin-bottom:3px;}
.agt-im{font-size:12px;color:var(--t2);display:flex;align-items:center;gap:4px;margin-bottom:2px;}
.agt-cor{font-size:11px;color:var(--t3);display:flex;align-items:center;gap:5px;}
.agt-obs{font-size:11px;color:var(--t2);font-style:italic;margin-top:5px;opacity:.7;}
.agt-right{display:flex;flex-direction:column;align-items:flex-end;gap:7px;flex-shrink:0;}
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.82);z-index:1000;display:flex;align-items:center;justify-content:center;padding:12px;backdrop-filter:blur(6px);animation:fadein .18s;}
@keyframes fadein{from{opacity:0;}to{opacity:1;}}
.modal-box{background:var(--card);border:1px solid var(--b2);border-radius:14px;width:100%;max-width:520px;max-height:92vh;display:flex;flex-direction:column;animation:slideup .2s cubic-bezier(.4,0,.2,1);}
.modal-box.wide{max-width:660px;}
@keyframes slideup{from{transform:translateY(14px);opacity:0;}to{transform:translateY(0);opacity:1;}}
.modal-head{display:flex;align-items:center;justify-content:space-between;padding:15px 17px;border-bottom:1px solid var(--b1);flex-shrink:0;}
.modal-head h3{font-family:'Bricolage Grotesque',sans-serif;font-size:15px;font-weight:700;color:#fff;}
.modal-body{overflow-y:auto;padding:17px;}
.form-g{display:grid;grid-template-columns:1fr 1fr;gap:11px;}
.fg{display:flex;flex-direction:column;gap:4px;}
.fg.full{grid-column:1/-1;}
.fg label{font-size:10px;letter-spacing:.7px;text-transform:uppercase;color:var(--t3);}
.fg small{display:block;color:var(--t3);font-size:10px;margin-top:2px;}
.perfil-wrap{display:flex;flex-direction:column;gap:16px;}
.perfil-top{display:flex;align-items:center;gap:14px;padding:14px;background:var(--card2);border-radius:10px;}
.perfil-info{display:grid;grid-template-columns:1fr 1fr;gap:9px;}
.pi-row{display:flex;align-items:flex-start;gap:9px;padding:10px;background:var(--card2);border-radius:8px;}
.pi-row span{display:block;font-size:9px;text-transform:uppercase;letter-spacing:.6px;color:var(--t3);margin-bottom:2px;}
.pi-row p{font-size:13px;color:#fff;}
.perfil-nums{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;}
.pnum{background:var(--card2);border-radius:8px;padding:12px;text-align:center;}
.pnum span{display:block;font-family:'Bricolage Grotesque',sans-serif;font-size:22px;font-weight:700;line-height:1;}
.pnum small{display:block;font-size:10px;color:var(--t2);margin-top:3px;text-transform:uppercase;letter-spacing:.4px;}
.ai-wrap{display:flex;flex-direction:column;gap:13px;}
.ai-lead-info{display:flex;align-items:center;gap:10px;background:var(--card2);border:1px solid var(--b2);border-radius:9px;padding:12px;}
.ai-nome{font-size:14px;font-weight:600;color:#fff;}
.ai-meta{font-size:11px;color:var(--t2);}
.ai-actions{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;}
.ai-act-btn{display:flex;align-items:center;justify-content:center;gap:6px;padding:9px;background:rgba(201,169,110,.07);border:1px solid rgba(201,169,110,.18);border-radius:8px;color:var(--g);font-size:12px;font-weight:600;transition:all .18s;}
.ai-act-btn:hover{background:rgba(201,169,110,.14);}
.ai-input-row{display:flex;gap:7px;}
.ai-input-row input{flex:1;}
.ai-send{width:38px;height:38px;border-radius:8px;background:var(--g);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .18s;}
.ai-send:hover{background:var(--g2);}
.ai-output{min-height:150px;background:var(--card2);border:1px solid var(--b2);border-radius:9px;padding:13px;}
.ai-loading{display:flex;flex-direction:column;align-items:center;gap:10px;padding:24px;}
.dots{display:flex;gap:5px;}
.dots s{width:7px;height:7px;border-radius:50%;background:var(--g);animation:dot .8s ease-in-out infinite;text-decoration:none;}
.dots s:nth-child(2){animation-delay:.15s;}
.dots s:nth-child(3){animation-delay:.3s;}
@keyframes dot{0%,100%{transform:translateY(0);}50%{transform:translateY(-6px);}}
.ai-loading span{font-size:12px;color:var(--t2);}
.ai-text{display:flex;flex-direction:column;gap:5px;}
.ai-text p{font-size:13px;color:var(--t1);line-height:1.7;}
.ai-empty{display:flex;flex-direction:column;align-items:center;gap:9px;padding:24px;color:var(--t3);}
.ai-empty p{font-size:12px;text-align:center;}
.login-root{display:flex;min-height:100vh;overflow:auto;}
.login-panel{width:440px;min-width:440px;background:var(--sb);border-right:1px solid var(--b1);padding:36px 32px;display:flex;flex-direction:column;overflow-y:auto;}
.login-visual{flex:1;position:relative;overflow:hidden;display:flex;align-items:flex-end;}
.lv-bg{position:absolute;inset:0;background:url('https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1400&q=70') center/cover;}
.lv-overlay{position:absolute;inset:0;background:linear-gradient(160deg,rgba(8,8,8,.75) 0%,rgba(8,8,8,.88) 100%);}
.lv-content{position:relative;z-index:1;padding:48px;}
.lv-content h2{font-family:'Bricolage Grotesque',sans-serif;font-size:clamp(26px,3vw,40px);font-weight:700;color:#fff;line-height:1.2;margin-bottom:14px;}
.lv-content p{font-size:15px;color:rgba(255,255,255,.6);line-height:1.7;margin-bottom:28px;max-width:440px;}
.lv-features{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.lv-feat{display:flex;align-items:center;gap:8px;font-size:13px;color:rgba(255,255,255,.7);}
.login-brand{display:flex;align-items:center;gap:10px;margin-bottom:36px;}
.brand-mark{width:36px;height:36px;background:var(--g);border-radius:9px;display:flex;align-items:center;justify-content:center;font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:18px;color:#000;flex-shrink:0;}
.brand-eye{font-size:8px;letter-spacing:2.5px;color:var(--g);font-weight:600;line-height:1.3;}
.brand-name{font-family:'Bricolage Grotesque',sans-serif;font-size:16px;font-weight:800;color:#fff;letter-spacing:.5px;}
.brand-name span{color:var(--g);}
.login-h1{font-family:'Bricolage Grotesque',sans-serif;font-size:26px;font-weight:700;color:#fff;margin-bottom:6px;}
.login-sub{font-size:13px;color:var(--t2);margin-bottom:24px;}
.lf-field{display:flex;flex-direction:column;gap:5px;margin-bottom:14px;}
.lf-field label{font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:var(--t3);}
.lf-wrap{display:flex;align-items:center;gap:8px;background:var(--card2);border:1px solid var(--b2);border-radius:9px;padding:0 11px;transition:border-color .2s;}
.lf-wrap:focus-within{border-color:rgba(201,169,110,.45);}
.lf-wrap input{background:none;border:none;padding:11px 0;flex:1;}
.lf-eye{padding:4px;color:var(--t3);display:flex;align-items:center;flex-shrink:0;}
.lf-erro{display:flex;align-items:center;gap:6px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#ef4444;padding:9px 12px;border-radius:8px;font-size:12px;margin-bottom:8px;}
.btn-login{width:100%;padding:12px;background:var(--g);color:#000;border-radius:9px;font-size:14px;font-weight:700;display:flex;align-items:center;justify-content:center;gap:8px;transition:background .2s;margin-bottom:22px;}
.btn-login:hover{background:var(--g2);}
.btn-login:disabled{opacity:.6;cursor:not-allowed;}
.spinner{width:17px;height:17px;border:2.5px solid rgba(0,0,0,.2);border-top-color:#000;border-radius:50%;animation:spin .65s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
.demo-sep{display:flex;align-items:center;gap:10px;margin-bottom:14px;}
.demo-sep::before,.demo-sep::after{content:'';flex:1;height:1px;background:var(--b1);}
.demo-sep span{font-size:11px;color:var(--t3);white-space:nowrap;}
.demo-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:12px;}
.demo-btn{display:flex;align-items:center;gap:7px;padding:9px 10px;background:var(--card);border:1px solid var(--b1);border-radius:8px;transition:all .18s;text-align:left;}
.demo-btn:hover{border-color:rgba(201,169,110,.25);background:var(--card2);}
.demo-btn.sel{border-color:var(--g);background:rgba(201,169,110,.05);}
.demo-nome{font-size:12px;font-weight:600;color:#fff;}
.demo-cargo{font-size:9px;color:var(--t3);}
.demo-admin{margin-left:auto;font-size:9px;font-weight:700;color:var(--g);background:rgba(201,169,110,.1);padding:2px 6px;border-radius:4px;white-space:nowrap;}
.btn-quick{width:100%;padding:10px;background:rgba(201,169,110,.1);border:1px solid rgba(201,169,110,.25);color:var(--g);border-radius:9px;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;gap:7px;transition:all .2s;}
.btn-quick:hover{background:rgba(201,169,110,.18);}
.row{display:flex;align-items:center;}
.row-end{display:flex;align-items:center;justify-content:flex-end;}
.gap4{gap:4px;}.gap6{gap:6px;}.gap8{gap:8px;}
.chip{background:rgba(255,255,255,.04);border:1px solid var(--b2);padding:2px 6px;border-radius:4px;font-size:10px;color:var(--t2);}
.chip.gold{color:var(--g);border-color:rgba(201,169,110,.18);}
.wrap{flex-wrap:wrap;}
@media(max-width:1100px){.kpi-grid{grid-template-columns:repeat(2,1fr);}.dash-cols{grid-template-columns:1fr;}}
@media(max-width:900px){.login-visual{display:none;}.login-panel{width:100%;min-width:unset;border-right:none;}}
@media(max-width:768px){
  .sb{position:fixed;top:0;left:0;bottom:0;transform:translateX(-100%);}
  .sb.open{transform:translateX(0);}
  .sb-ov{display:block;}
  .mob-menu{display:flex;}
  .mob-nav{display:flex;}
  .content{padding-bottom:68px;}
  .page{padding:14px;}
  .kpi-grid{grid-template-columns:repeat(2,1fr);}
  .form-g{grid-template-columns:1fr;}
  .ai-actions{grid-template-columns:1fr;}
  .agt-right{display:none;}
  .im-grid{grid-template-columns:1fr;}
  .pipe-row{grid-template-columns:100px 1fr 22px;}
  .perfil-info{grid-template-columns:1fr;}
  .perfil-nums{grid-template-columns:repeat(2,1fr);}
  .eq-head,.eq-row{grid-template-columns:2fr 1fr 1fr 1fr;}
  .eq-head span:nth-child(5),.eq-row span:nth-child(5){display:none;}
}
@media(max-width:480px){
  .kpi-grid{grid-template-columns:1fr;}
  .modal-box{max-height:95vh;}
  .filt-row select{width:100%;}
  .demo-grid{grid-template-columns:1fr;}
  .lv-features{grid-template-columns:1fr;}
}
`;
